﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace Lab04_ProductManager
{
    internal class Program
    {
        private static ProductService service = new ProductService();

        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;
            Console.Title = "COMP1019 - Lab 04: Product Management | Trần Vũ Hoa` Phát";

            // =====================================================================
            // ĐĂNG KÝ EVENT THÔNG BÁO KHI THÊM / XÓA SẢN PHẨM THÀNH CÔNG
            // =====================================================================
            service.OnProductAdded += (p) =>
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"\n  🔔 [EVENT NOTIFICATION]: Đã thêm thành công sản phẩm: [{p.MaSP}] {p.TenSP} (Giá: {p.Price:N0} đ, SL: {p.Quantity})!");
                Console.ResetColor();
            };

            service.OnProductRemoved += (p) =>
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine($"\n  🔔 [EVENT NOTIFICATION]: Đã xóa sản phẩm: [{p.MaSP}] {p.TenSP} ra khỏi kho hàng!");
                Console.ResetColor();
            };

            int luaChon = -1;
            do
            {
                Console.Clear();
                HienThiBanner();
                HienThiMenu();

                luaChon = NhapSoNguyen(" » Chọn chức năng [0-7]: ");
                Console.WriteLine();

                switch (luaChon)
                {
                    case 1:
                        InTieuDe("1. THÊM SẢN PHẨM MỚI");
                        ChucNangThem();
                        break;

                    case 2:
                        InTieuDe("2. XUẤT DANH SÁCH SẢN PHẨM");
                        InBangSanPham(service.GetAllProducts());
                        break;

                    case 3:
                        InTieuDe("3. TÌM KIẾM THEO MÃ SẢN PHẨM");
                        ChucNangTimTheoMa();
                        break;

                    case 4:
                        InTieuDe("4. TÌM KIẾM THEO TÊN SẢN PHẨM");
                        ChucNangTimTheoTen();
                        break;

                    case 5:
                        InTieuDe("5. LỌC SẢN PHẨM THEO KHOẢNG GIÁ (FUNC DELEGATE)");
                        ChucNangLocTheoKhoangGia();
                        break;

                    case 6:
                        InTieuDe("6. XÓA SẢN PHẨM KHỎI HỆ THỐNG");
                        ChucNangXoa();
                        break;

                    case 7:
                        InTieuDe("7. TỔNG GIÁ TRỊ TỒN KHO HÀNG HÓA");
                        ChucNangTongGiaTri();
                        break;

                    case 0:
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("╔════════════════════════════════════════════════════════════════════╗");
                        Console.WriteLine("║        CẢM ƠN BẠN ĐÃ SỬ DỤNG HỆ THỐNG PRODUCT MANAGER!             ║");
                        Console.WriteLine("╚════════════════════════════════════════════════════════════════════╝");
                        Console.ResetColor();
                        break;

                    default:
                        InLoi("Lựa chọn không hợp lệ! Vui lòng chọn từ 0 đến 7.");
                        break;
                }

                if (luaChon != 0)
                {
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.Write("  [Nhấn phím bất kỳ để quay lại Menu...]");
                    Console.ResetColor();
                    Console.ReadKey();
                }

            } while (luaChon != 0);
        }

        // =========================================================================
        // XỬ LÝ NGHIỆP VỤ & BẮT LỖI TRY-CATCH CHO TỪNG CHỨC NĂNG
        // =========================================================================

        static void ChucNangThem()
        {
            try
            {
                string ma = NhapChuoi(" » Nhập mã sản phẩm: ");
                string ten = NhapChuoi(" » Nhập tên sản phẩm: ");
                double gia = NhapSoThucDuong(" » Nhập đơn giá (VNĐ): ");
                int sl = NhapSoNguyenDuong(" » Nhập số lượng tồn kho: ");

                Product p = new Product(ma, ten, gia, sl);
                service.AddProduct(p); // Hàm này tự động phát sinh Event OnProductAdded
            }
            catch (DuplicateProductException ex)
            {
                InLoi($"[Lỗi trùng mã]: {ex.Message}");
            }
            catch (ArgumentException ex)
            {
                InLoi($"[Lỗi dữ liệu]: {ex.Message}");
            }
            catch (Exception ex)
            {
                InLoi($"[Lỗi không xác định]: {ex.Message}");
            }
        }

        static void ChucNangTimTheoMa()
        {
            string ma = NhapChuoi(" » Nhập mã sản phẩm cần tìm: ");
            var p = service.FindById(ma);
            if (p != null)
            {
                InThanhCong("Đã tìm thấy sản phẩm:");
                InBangSanPham(new List<Product> { p });
            }
            else
            {
                InCanhBao($"Không tìm thấy sản phẩm có mã '{ma}' trong hệ thống!");
            }
        }

        static void ChucNangTimTheoTen()
        {
            string tuKhoa = NhapChuoi(" » Nhập từ khóa tên cần tìm: ");
            var list = service.SearchByName(tuKhoa);
            if (list.Count > 0)
            {
                InThanhCong($"Tìm thấy {list.Count} sản phẩm phù hợp:");
                InBangSanPham(list);
            }
            else
            {
                InCanhBao($"Không có sản phẩm nào chứa từ khóa '{tuKhoa}'!");
            }
        }

        static void ChucNangLocTheoKhoangGia()
        {
            double min = NhapSoThucDuong(" » Nhập khoảng giá từ (VNĐ): ");
            double max = NhapSoThucDuong(" » Nhập khoảng giá đến (VNĐ): ");

            if (min > max)
            {
                InLoi("Giá bắt đầu không thể lớn hơn giá kết thúc!");
                return;
            }

            var list = service.FilterByPrice(min, max);
            if (list.Count > 0)
            {
                InThanhCong($"Tìm thấy {list.Count} sản phẩm trong tầm giá {min:N0} đ - {max:N0} đ:");
                InBangSanPham(list);
            }
            else
            {
                InCanhBao($"Không có sản phẩm nào nằm trong tầm giá này!");
            }
        }

        static void ChucNangXoa()
        {
            try
            {
                string ma = NhapChuoi(" » Nhập mã sản phẩm cần xóa: ");
                service.RemoveProduct(ma); // Ném ProductNotFoundException nếu không có
            }
            catch (ProductNotFoundException ex)
            {
                InLoi($"[Lỗi xóa sản phẩm]: {ex.Message}");
            }
            catch (Exception ex)
            {
                InLoi($"[Lỗi]: {ex.Message}");
            }
        }

        static void ChucNangTongGiaTri()
        {
            var list = service.GetAllProducts();
            InBangSanPham(list);
            double total = service.CalculateTotalInventoryValue();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("  ┌────────────────────────────────────────────────────────┐");
            Console.WriteLine($"  │  ► TỔNG GIÁ TRỊ KHO: {total,28:N0} VNĐ  │");
            Console.WriteLine("  └────────────────────────────────────────────────────────┘");
            Console.ResetColor();
        }

        // =========================================================================
        // CÁC HÀM NHẬP DỮ LIỆU AN TOÀN
        // =========================================================================

        static string NhapChuoi(string msg)
        {
            while (true)
            {
                Console.Write(msg);
                string s = Console.ReadLine()?.Trim();
                if (!string.IsNullOrEmpty(s)) return s;
                InLoi("Giá trị không được rỗng!");
            }
        }

        static int NhapSoNguyen(string msg)
        {
            while (true)
            {
                Console.Write(msg);
                if (int.TryParse(Console.ReadLine(), out int n)) return n;
                InLoi("Vui lòng nhập số nguyên hợp lệ!");
            }
        }

        static int NhapSoNguyenDuong(string msg)
        {
            while (true)
            {
                int n = NhapSoNguyen(msg);
                if (n >= 0) return n;
                InLoi("Số lượng không được âm!");
            }
        }

        static double NhapSoThucDuong(string msg)
        {
            while (true)
            {
                Console.Write(msg);
                string input = Console.ReadLine()?.Replace(',', '.');
                if (double.TryParse(input, NumberStyles.Any, CultureInfo.InvariantCulture, out double d))
                {
                    if (d >= 0) return d;
                    InLoi("Đơn giá không được âm!");
                }
                else
                {
                    InLoi("Vui lòng nhập số thực hợp lệ!");
                }
            }
        }

        // =========================================================================
        // GIAO DIỆN & VẼ BẢNG
        // =========================================================================

        static void HienThiBanner()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("╔════════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║            HỌC PHẦN COMP1019 - LẬP TRÌNH TRÊN WINDOWS              ║");
            Console.WriteLine("║        LAB 04: QUẢN LÝ SẢN PHẨM (EXCEPTION - EVENT - GENERIC)      ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════════════════╝");
            Console.ResetColor();
        }

        static void HienThiMenu()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("┌───────────────────────────── MENU CHÍNH ───────────────────────────┐");
            Console.WriteLine("│  [1] Thêm sản phẩm mới              [5] Lọc sản phẩm theo giá      │");
            Console.WriteLine("│  [2] Xuất danh sách sản phẩm        [6] Xóa sản phẩm               │");
            Console.WriteLine("│  [3] Tìm kiếm theo mã SP            [7] Tính tổng giá trị kho hàng │");
            Console.WriteLine("│  [4] Tìm kiếm theo tên              [0] Thoát chương trình         │");
            Console.WriteLine("└────────────────────────────────────────────────────────────────────┘");
            Console.ResetColor();
        }

        static void InBangSanPham(List<Product> list)
        {
            if (list == null || list.Count == 0)
            {
                InCanhBao("Kho hàng hiện tại không có sản phẩm nào!");
                return;
            }

            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("┌────────┬──────────────────────────┬──────────────┬──────┬─────────────────┐");
            Console.WriteLine("│ Mã SP  │ Tên sản phẩm             │ Đơn giá      │ SL   │ Thành tiền      │");
            Console.WriteLine("├────────┼──────────────────────────┼──────────────┼──────┼─────────────────┤");
            Console.ResetColor();

            foreach (var p in list)
            {
                Console.WriteLine($"│ {p.MaSP,-6} │ {p.TenSP,-24} │ {p.Price,10:N0} đ │ {p.Quantity,4} │ {(p.Price * p.Quantity),13:N0} đ │");
            }

            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("└────────┴──────────────────────────┴──────────────┴──────┴─────────────────┘");
            Console.ResetColor();
        }

        static void InTieuDe(string title)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"═══► {title}\n");
            Console.ResetColor();
        }

        static void InThanhCong(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"  ✔ [THÀNH CÔNG]: {msg}");
            Console.ResetColor();
        }

        static void InLoi(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"  ✖ [LỖI]: {msg}");
            Console.ResetColor();
        }

        static void InCanhBao(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"  ⚠ [CẢNH BÁO]: {msg}");
            Console.ResetColor();
        }
    }
}