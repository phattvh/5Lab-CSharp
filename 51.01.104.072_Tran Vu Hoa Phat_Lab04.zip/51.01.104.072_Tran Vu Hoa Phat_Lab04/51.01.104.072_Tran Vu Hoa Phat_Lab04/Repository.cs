﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Lab04_ProductManager
{
    /// <summary>
    /// Lớp Generic quản lý đối tượng T với ràng buộc T phải kế thừa IEntity
    /// </summary>
    public class Repository<T> where T : IEntity
    {
        protected readonly List<T> _items = new List<T>();

        // Thêm đối tượng
        public virtual void Add(T item)
        {
            _items.Add(item);
        }

        // Xóa đối tượng theo Id
        public virtual bool Remove(string id)
        {
            var item = FindById(id);
            if (item != null)
            {
                return _items.Remove(item);
            }
            return false;
        }

        // Tìm theo Id (sử dụng thuộc tính Id của IEntity)
        public virtual T FindById(string id)
        {
            return _items.FirstOrDefault(x => x.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
        }

        // Tìm kiếm/Lọc theo điều kiện linh hoạt sử dụng Func<T, bool>
        public virtual IEnumerable<T> Find(Func<T, bool> predicate)
        {
            return _items.Where(predicate);
        }

        // Lấy toàn bộ danh sách
        public virtual List<T> GetAll()
        {
            return _items;
        }
    }
}