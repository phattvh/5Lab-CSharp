﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Lab04_ProductManager
{
    public class ProductService
    {
        private readonly Repository<Product> _repo;

        // SỬ DỤNG EVENT (Action delegate) để thông báo khi dữ liệu thay đổi
        public event Action<Product> OnProductAdded;
        public event Action<Product> OnProductRemoved;

        public ProductService()
        {
            _repo = new Repository<Product>();
            KhoiTaoDuLieuMau();
        }

        private void KhoiTaoDuLieuMau()
        {
            _repo.Add(new Product("SP01", "Bàn phím cơ AKKO", 1250000, 15));
            _repo.Add(new Product("SP02", "Chuột Logitech G102", 420000, 25));
            _repo.Add(new Product("SP03", "Tai nghe Gaming HyperX", 1850000, 8));
            _repo.Add(new Product("SP04", "Lót chuột khổ lớn RGB", 190000, 50));
            _repo.Add(new Product("SP05", "Màn hình Dell 24 inch", 3490000, 10));
        }

        /// <summary>
        /// [Chức năng 1] Thêm sản phẩm: Ném DuplicateProductException nếu trùng mã
        /// </summary>
        public void AddProduct(Product product)
        {
            if (string.IsNullOrWhiteSpace(product.MaSP))
                throw new ArgumentException("Mã sản phẩm không được để trống!");

            // Kiểm tra trùng mã
            if (_repo.FindById(product.MaSP) != null)
            {
                throw new DuplicateProductException($"Mã sản phẩm '{product.MaSP}' đã tồn tại trong hệ thống!");
            }

            _repo.Add(product);

            // BẮN SỰ KIỆN KHI THÊM THÀNH CÔNG
            OnProductAdded?.Invoke(product);
        }

        /// <summary>
        /// [Chức năng 6] Xóa sản phẩm: Ném ProductNotFoundException nếu không tìm thấy
        /// </summary>
        public void RemoveProduct(string maSP)
        {
            var p = _repo.FindById(maSP);
            if (p == null)
            {
                throw new ProductNotFoundException($"Không tìm thấy sản phẩm có mã '{maSP}' để xóa!");
            }

            _repo.Remove(maSP);

            // BẮN SỰ KIỆN KHI XÓA THÀNH CÔNG
            OnProductRemoved?.Invoke(p);
        }

        /// <summary>
        /// [Chức năng 3] Tìm theo mã
        /// </summary>
        public Product FindById(string maSP)
        {
            return _repo.FindById(maSP);
        }

        /// <summary>
        /// [Chức năng 4] Tìm theo tên (Sử dụng Func<Product, bool>)
        /// </summary>
        public List<Product> SearchByName(string keyword)
        {
            Func<Product, bool> condition = p => p.TenSP.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0;
            return _repo.Find(condition).ToList();
        }

        /// <summary>
        /// [Chức năng 5] Lọc theo khoảng giá (Sử dụng Func<Product, bool>)
        /// </summary>
        public List<Product> FilterByPrice(double minPrice, double maxPrice)
        {
            Func<Product, bool> priceCondition = p => p.Price >= minPrice && p.Price <= maxPrice;
            return _repo.Find(priceCondition).ToList();
        }

        /// <summary>
        /// [Chức năng 7] Tính tổng giá trị toàn kho hàng (Price * Quantity)
        /// </summary>
        public double CalculateTotalInventoryValue()
        {
            return _repo.GetAll().Sum(p => p.Price * p.Quantity);
        }

        public List<Product> GetAllProducts()
        {
            return _repo.GetAll();
        }
    }
}