﻿using System;

namespace Lab04_ProductManager
{
    /// <summary>
    /// Thực thể Sản phẩm kế thừa interface IEntity
    /// </summary>
    public class Product : IEntity
    {
        private double _price;
        private int _quantity;

        public string MaSP { get; set; }
        public string TenSP { get; set; }

        // Thực thi Id từ IEntity (ánh xạ tới MaSP)
        public string Id => MaSP;

        // Đơn giá không được âm
        public double Price
        {
            get => _price;
            set
            {
                if (value < 0)
                    throw new ArgumentException("Đơn giá sản phẩm không được là số âm!");
                _price = value;
            }
        }

        // Số lượng tồn kho không được âm
        public int Quantity
        {
            get => _quantity;
            set
            {
                if (value < 0)
                    throw new ArgumentException("Số lượng sản phẩm không được là số âm!");
                _quantity = value;
            }
        }

        public Product()
        {
            MaSP = string.Empty;
            TenSP = string.Empty;
            _price = 0;
            _quantity = 0;
        }

        public Product(string maSP, string tenSP, double price, int quantity)
        {
            MaSP = maSP;
            TenSP = tenSP;
            Price = price;       // Gán qua Property để tự kiểm tra dữ liệu >= 0
            Quantity = quantity; // Gán qua Property để tự kiểm tra dữ liệu >= 0
        }

        public override string ToString()
        {
            return $"[{MaSP,-6}] Tên: {TenSP,-22} | Giá: {Price,10:N0} đ | SL: {Quantity,4} | Thành tiền: {(Price * Quantity),12:N0} đ";
        }
    }
}