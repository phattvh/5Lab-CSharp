﻿namespace Lab04_ProductManager
{
    /// <summary>
    /// Interface dùng làm generic constraint (ràng buộc) cho Repository<T>
    /// </summary>
    public interface IEntity
    {
        string Id { get; }
    }
}