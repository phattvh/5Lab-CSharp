﻿using System;

namespace Lab04_ProductManager
{
    /// <summary>
    /// Phát sinh khi thêm sản phẩm có mã đã tồn tại trong kho
    /// </summary>
    public class DuplicateProductException : Exception
    {
        public DuplicateProductException(string message) : base(message) { }
    }

    /// <summary>
    /// Phát sinh khi tìm, sửa hoặc xóa sản phẩm không tồn tại
    /// </summary>
    public class ProductNotFoundException : Exception
    {
        public ProductNotFoundException(string message) : base(message) { }
    }
}