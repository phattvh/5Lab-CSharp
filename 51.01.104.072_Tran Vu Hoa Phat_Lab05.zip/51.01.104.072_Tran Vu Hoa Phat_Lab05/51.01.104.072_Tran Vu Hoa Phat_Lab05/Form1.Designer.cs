﻿namespace CourseRegistrationApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.grbThongTinHocVien = new System.Windows.Forms.GroupBox();
            this.chkNhanEmail = new System.Windows.Forms.CheckBox();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.txtSoDienThoai = new System.Windows.Forms.TextBox();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.lblNgaySinh = new System.Windows.Forms.Label();
            this.lblSoDienThoai = new System.Windows.Forms.Label();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.grbThongTinKhoaHoc = new System.Windows.Forms.GroupBox();
            this.lblTongTien = new System.Windows.Forms.Label();
            this.lblTieuDeTongTien = new System.Windows.Forms.Label();
            this.numSoThang = new System.Windows.Forms.NumericUpDown();
            this.radOffline = new System.Windows.Forms.RadioButton();
            this.radOnline = new System.Windows.Forms.RadioButton();
            this.cboKhoaHoc = new System.Windows.Forms.ComboBox();
            this.lblSoThang = new System.Windows.Forms.Label();
            this.lblHinhThuc = new System.Windows.Forms.Label();
            this.lblKhoaHoc = new System.Windows.Forms.Label();
            this.btnDangKy = new System.Windows.Forms.Button();
            this.btnLamMoi = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.grbThongTinHocVien.SuspendLayout();
            this.grbThongTinKhoaHoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoThang)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.AutoSize = true;
            this.lblTieuDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.lblTieuDe.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(233, 9);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(323, 25);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "HỆ THỐNG ĐĂNG KÝ KHÓA HỌC";
            // 
            // grbThongTinHocVien
            // 
            this.grbThongTinHocVien.Controls.Add(this.chkNhanEmail);
            this.grbThongTinHocVien.Controls.Add(this.dtpNgaySinh);
            this.grbThongTinHocVien.Controls.Add(this.txtSoDienThoai);
            this.grbThongTinHocVien.Controls.Add(this.txtHoTen);
            this.grbThongTinHocVien.Controls.Add(this.lblNgaySinh);
            this.grbThongTinHocVien.Controls.Add(this.lblSoDienThoai);
            this.grbThongTinHocVien.Controls.Add(this.lblHoTen);
            this.grbThongTinHocVien.Location = new System.Drawing.Point(76, 49);
            this.grbThongTinHocVien.Name = "grbThongTinHocVien";
            this.grbThongTinHocVien.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.grbThongTinHocVien.Size = new System.Drawing.Size(651, 124);
            this.grbThongTinHocVien.TabIndex = 1;
            this.grbThongTinHocVien.TabStop = false;
            this.grbThongTinHocVien.Text = "Thông tin học viên";
            // 
            // chkNhanEmail
            // 
            this.chkNhanEmail.AutoSize = true;
            this.chkNhanEmail.Location = new System.Drawing.Point(263, 91);
            this.chkNhanEmail.Name = "chkNhanEmail";
            this.chkNhanEmail.Size = new System.Drawing.Size(233, 17);
            this.chkNhanEmail.TabIndex = 7;
            this.chkNhanEmail.Text = "Nhận email thông báo về lịch học và tài liệu";
            this.chkNhanEmail.UseVisualStyleBackColor = true;
            // 
            // dtpNgaySinh
            // 
            this.dtpNgaySinh.CustomFormat = "dd/MM/yyyy";
            this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgaySinh.Location = new System.Drawing.Point(109, 86);
            this.dtpNgaySinh.Name = "dtpNgaySinh";
            this.dtpNgaySinh.Size = new System.Drawing.Size(110, 20);
            this.dtpNgaySinh.TabIndex = 6;
            // 
            // txtSoDienThoai
            // 
            this.txtSoDienThoai.Location = new System.Drawing.Point(109, 55);
            this.txtSoDienThoai.Name = "txtSoDienThoai";
            this.txtSoDienThoai.Size = new System.Drawing.Size(491, 20);
            this.txtSoDienThoai.TabIndex = 4;
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(109, 24);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(491, 20);
            this.txtHoTen.TabIndex = 3;
            // 
            // lblNgaySinh
            // 
            this.lblNgaySinh.AutoSize = true;
            this.lblNgaySinh.Location = new System.Drawing.Point(28, 91);
            this.lblNgaySinh.Name = "lblNgaySinh";
            this.lblNgaySinh.Size = new System.Drawing.Size(57, 13);
            this.lblNgaySinh.TabIndex = 2;
            this.lblNgaySinh.Text = "Ngày sinh:";
            // 
            // lblSoDienThoai
            // 
            this.lblSoDienThoai.AutoSize = true;
            this.lblSoDienThoai.Location = new System.Drawing.Point(28, 58);
            this.lblSoDienThoai.Name = "lblSoDienThoai";
            this.lblSoDienThoai.Size = new System.Drawing.Size(73, 13);
            this.lblSoDienThoai.TabIndex = 1;
            this.lblSoDienThoai.Text = "Số điện thoại:";
            // 
            // lblHoTen
            // 
            this.lblHoTen.AutoSize = true;
            this.lblHoTen.Location = new System.Drawing.Point(28, 27);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(57, 13);
            this.lblHoTen.TabIndex = 0;
            this.lblHoTen.Text = "Họ và tên:";
            // 
            // grbThongTinKhoaHoc
            // 
            this.grbThongTinKhoaHoc.Controls.Add(this.lblTongTien);
            this.grbThongTinKhoaHoc.Controls.Add(this.lblTieuDeTongTien);
            this.grbThongTinKhoaHoc.Controls.Add(this.numSoThang);
            this.grbThongTinKhoaHoc.Controls.Add(this.radOffline);
            this.grbThongTinKhoaHoc.Controls.Add(this.radOnline);
            this.grbThongTinKhoaHoc.Controls.Add(this.cboKhoaHoc);
            this.grbThongTinKhoaHoc.Controls.Add(this.lblSoThang);
            this.grbThongTinKhoaHoc.Controls.Add(this.lblHinhThuc);
            this.grbThongTinKhoaHoc.Controls.Add(this.lblKhoaHoc);
            this.grbThongTinKhoaHoc.Location = new System.Drawing.Point(76, 192);
            this.grbThongTinKhoaHoc.Name = "grbThongTinKhoaHoc";
            this.grbThongTinKhoaHoc.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.grbThongTinKhoaHoc.Size = new System.Drawing.Size(651, 174);
            this.grbThongTinKhoaHoc.TabIndex = 2;
            this.grbThongTinKhoaHoc.TabStop = false;
            this.grbThongTinKhoaHoc.Text = "Thông tin khóa học";
            // 
            // lblTongTien
            // 
            this.lblTongTien.AutoSize = true;
            this.lblTongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.lblTongTien.ForeColor = System.Drawing.Color.Red;
            this.lblTongTien.Location = new System.Drawing.Point(134, 129);
            this.lblTongTien.Name = "lblTongTien";
            this.lblTongTien.Size = new System.Drawing.Size(63, 22);
            this.lblTongTien.TabIndex = 12;
            this.lblTongTien.Text = "0 VNĐ";
            // 
            // lblTieuDeTongTien
            // 
            this.lblTieuDeTongTien.AutoSize = true;
            this.lblTieuDeTongTien.Location = new System.Drawing.Point(28, 134);
            this.lblTieuDeTongTien.Name = "lblTieuDeTongTien";
            this.lblTieuDeTongTien.Size = new System.Drawing.Size(75, 13);
            this.lblTieuDeTongTien.TabIndex = 3;
            this.lblTieuDeTongTien.Text = "Tổng học phí:";
            // 
            // numSoThang
            // 
            this.numSoThang.Location = new System.Drawing.Point(138, 94);
            this.numSoThang.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.numSoThang.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numSoThang.Name = "numSoThang";
            this.numSoThang.Size = new System.Drawing.Size(120, 20);
            this.numSoThang.TabIndex = 11;
            this.numSoThang.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // radOffline
            // 
            this.radOffline.AutoSize = true;
            this.radOffline.Location = new System.Drawing.Point(370, 60);
            this.radOffline.Name = "radOffline";
            this.radOffline.Size = new System.Drawing.Size(126, 17);
            this.radOffline.TabIndex = 10;
            this.radOffline.Text = "Offline (Tại trung tâm)";
            this.radOffline.UseVisualStyleBackColor = true;
            // 
            // radOnline
            // 
            this.radOnline.AutoSize = true;
            this.radOnline.Checked = true;
            this.radOnline.Location = new System.Drawing.Point(180, 60);
            this.radOnline.Name = "radOnline";
            this.radOnline.Size = new System.Drawing.Size(115, 17);
            this.radOnline.TabIndex = 9;
            this.radOnline.TabStop = true;
            this.radOnline.Text = "Online (Trực tuyến)";
            this.radOnline.UseVisualStyleBackColor = true;
            // 
            // cboKhoaHoc
            // 
            this.cboKhoaHoc.AllowDrop = true;
            this.cboKhoaHoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboKhoaHoc.FormattingEnabled = true;
            this.cboKhoaHoc.Location = new System.Drawing.Point(109, 24);
            this.cboKhoaHoc.Name = "cboKhoaHoc";
            this.cboKhoaHoc.Size = new System.Drawing.Size(491, 21);
            this.cboKhoaHoc.TabIndex = 8;
            // 
            // lblSoThang
            // 
            this.lblSoThang.AutoSize = true;
            this.lblSoThang.Location = new System.Drawing.Point(27, 96);
            this.lblSoThang.Name = "lblSoThang";
            this.lblSoThang.Size = new System.Drawing.Size(95, 13);
            this.lblSoThang.TabIndex = 2;
            this.lblSoThang.Text = "Số tháng đăng ký:";
            // 
            // lblHinhThuc
            // 
            this.lblHinhThuc.AutoSize = true;
            this.lblHinhThuc.Location = new System.Drawing.Point(27, 62);
            this.lblHinhThuc.Name = "lblHinhThuc";
            this.lblHinhThuc.Size = new System.Drawing.Size(77, 13);
            this.lblHinhThuc.TabIndex = 1;
            this.lblHinhThuc.Text = "Hình thức học:";
            // 
            // lblKhoaHoc
            // 
            this.lblKhoaHoc.AutoSize = true;
            this.lblKhoaHoc.Location = new System.Drawing.Point(28, 27);
            this.lblKhoaHoc.Name = "lblKhoaHoc";
            this.lblKhoaHoc.Size = new System.Drawing.Size(56, 13);
            this.lblKhoaHoc.TabIndex = 0;
            this.lblKhoaHoc.Text = "Khóa học:";
            // 
            // btnDangKy
            // 
            this.btnDangKy.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnDangKy.ForeColor = System.Drawing.Color.Green;
            this.btnDangKy.Location = new System.Drawing.Point(165, 389);
            this.btnDangKy.Name = "btnDangKy";
            this.btnDangKy.Size = new System.Drawing.Size(90, 31);
            this.btnDangKy.TabIndex = 3;
            this.btnDangKy.Text = "Đăng ký";
            this.btnDangKy.UseVisualStyleBackColor = true;
            this.btnDangKy.Click += new System.EventHandler(this.btnDangKy_Click);
            // 
            // btnLamMoi
            // 
            this.btnLamMoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnLamMoi.ForeColor = System.Drawing.Color.Green;
            this.btnLamMoi.Location = new System.Drawing.Point(356, 389);
            this.btnLamMoi.Name = "btnLamMoi";
            this.btnLamMoi.Size = new System.Drawing.Size(90, 31);
            this.btnLamMoi.TabIndex = 4;
            this.btnLamMoi.Text = "Làm mới";
            this.btnLamMoi.UseVisualStyleBackColor = true;
            this.btnLamMoi.Click += new System.EventHandler(this.btnLamMoi_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnThoat.ForeColor = System.Drawing.Color.Green;
            this.btnThoat.Location = new System.Drawing.Point(537, 389);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(90, 31);
            this.btnThoat.TabIndex = 5;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnLamMoi);
            this.Controls.Add(this.btnDangKy);
            this.Controls.Add(this.grbThongTinKhoaHoc);
            this.Controls.Add(this.grbThongTinHocVien);
            this.Controls.Add(this.lblTieuDe);
            this.Name = "Form1";
            this.Text = "Tổng học phí:";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grbThongTinHocVien.ResumeLayout(false);
            this.grbThongTinHocVien.PerformLayout();
            this.grbThongTinKhoaHoc.ResumeLayout(false);
            this.grbThongTinKhoaHoc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoThang)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.GroupBox grbThongTinHocVien;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label lblNgaySinh;
        private System.Windows.Forms.Label lblSoDienThoai;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.TextBox txtSoDienThoai;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.CheckBox chkNhanEmail;
        private System.Windows.Forms.GroupBox grbThongTinKhoaHoc;
        private System.Windows.Forms.Label lblSoThang;
        private System.Windows.Forms.Label lblHinhThuc;
        private System.Windows.Forms.Label lblKhoaHoc;
        private System.Windows.Forms.ComboBox cboKhoaHoc;
        private System.Windows.Forms.RadioButton radOffline;
        private System.Windows.Forms.RadioButton radOnline;
        private System.Windows.Forms.NumericUpDown numSoThang;
        private System.Windows.Forms.Label lblTieuDeTongTien;
        private System.Windows.Forms.Label lblTongTien;
        private System.Windows.Forms.Button btnDangKy;
        private System.Windows.Forms.Button btnLamMoi;
        private System.Windows.Forms.Button btnThoat;
    }
}

