﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace CourseRegistrationApp
{
    public partial class Form1 : Form
    {
        // Danh sách lưu trữ thông tin khóa học và học phí/tháng tương ứng
        private readonly Dictionary<string, decimal> _danhSachKhoaHoc = new Dictionary<string, decimal>()
        {
            { "C# WinForms cơ bản", 800000m },
            { "SQL Server cơ bản", 700000m },
            { "Web Frontend cơ bản", 750000m },
            { "Lập trình Python cơ bản", 650000m }
        };

        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 5.1 Khi Form Load: Khởi tạo dữ liệu ban đầu
        /// </summary>
        private void Form1_Load(object sender, EventArgs e)
        {
            // 1. Nạp danh sách khóa học vào ComboBox
            cboKhoaHoc.Items.Clear();
            foreach (var khoaHoc in _danhSachKhoaHoc.Keys)
            {
                cboKhoaHoc.Items.Add(khoaHoc);
            }

            // 2. Chọn mặc định khóa học đầu tiên
            if (cboKhoaHoc.Items.Count > 0)
            {
                cboKhoaHoc.SelectedIndex = 0;
            }

            // 3. Chọn mặc định hình thức Online
            radOnline.Checked = true;

            // 4. Thiết lập số tháng tối thiểu 1, tối đa 12 và giá trị mặc định là 1
            numSoThang.Minimum = 1;
            numSoThang.Maximum = 12;
            numSoThang.Value = 1;

            // 5. Tính toán và hiển thị tổng học phí ban đầu
            CapNhatTongTien();

            // Đặt con trỏ nhập liệu vào ô Họ tên
            txtHoTen.Focus();
        }

        /// <summary>
        /// Tự động cập nhật tổng học phí khi thay đổi Khóa học
        /// </summary>
        private void cboKhoaHoc_SelectedIndexChanged(object sender, EventArgs e)
        {
            CapNhatTongTien();
        }

        /// <summary>
        /// Tự động cập nhật tổng học phí khi thay đổi Số tháng
        /// </summary>
        private void numSoThang_ValueChanged(object sender, EventArgs e)
        {
            CapNhatTongTien();
        }

        /// <summary>
        /// Hàm phụ trợ tính tổng học phí = học phí/tháng x số tháng
        /// </summary>
        private decimal TinhTongHocPhi()
        {
            if (cboKhoaHoc.SelectedItem == null) return 0;

            string tenKhoaHoc = cboKhoaHoc.SelectedItem.ToString();
            if (_danhSachKhoaHoc.ContainsKey(tenKhoaHoc))
            {
                decimal hocPhi1Thang = _danhSachKhoaHoc[tenKhoaHoc];
                int soThang = (int)numSoThang.Value;
                return hocPhi1Thang * soThang;
            }
            return 0;
        }

        /// <summary>
        /// Hiển thị tổng tiền được format định dạng tiền tệ VNĐ (ví dụ: 800.000 VNĐ)
        /// </summary>
        private void CapNhatTongTien()
        {
            decimal tongTien = TinhTongHocPhi();
            lblTongTien.Text = $"{tongTien:N0} VNĐ";
        }

        /// <summary>
        /// 5.2 Xử lý nút ĐĂNG KÝ
        /// </summary>
        private void btnDangKy_Click(object sender, EventArgs e)
        {
            // 1. Kiểm tra Họ tên không được để trống
            string hoTen = txtHoTen.Text.Trim();
            if (string.IsNullOrWhiteSpace(hoTen))
            {
                MessageBox.Show("Vui lòng nhập họ và tên học viên!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtHoTen.Focus();
                return;
            }

            // 2. Kiểm tra Số điện thoại không được để trống
            string soDienThoai = txtSoDienThoai.Text.Trim();
            if (string.IsNullOrWhiteSpace(soDienThoai))
            {
                MessageBox.Show("Vui lòng nhập số điện thoại liên hệ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSoDienThoai.Focus();
                return;
            }

            // 3. Kiểm tra chọn khóa học
            if (cboKhoaHoc.SelectedIndex == -1 || cboKhoaHoc.SelectedItem == null)
            {
                MessageBox.Show("Vui lòng chọn khóa học!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboKhoaHoc.Focus();
                return;
            }

            // Thu thập dữ liệu đăng ký
            string ngaySinh = dtpNgaySinh.Value.ToString("dd/MM/yyyy");
            string khoaHoc = cboKhoaHoc.SelectedItem.ToString();
            string hinhThuc = radOnline.Checked ? "Online (Trực tuyến)" : "Offline (Tại trung tâm)";
            int soThang = (int)numSoThang.Value;
            decimal tongTien = TinhTongHocPhi();
            string nhanEmail = chkNhanEmail.Checked ? "Có" : "Không";

            // Xây dựng nội dung phiếu đăng ký hiển thị qua MessageBox
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("════════════════════════════════════");
            sb.AppendLine("        PHIẾU ĐĂNG KÝ KHÓA HỌC        ");
            sb.AppendLine("════════════════════════════════════");
            sb.AppendLine($"• Họ và tên:       {hoTen}");
            sb.AppendLine($"• Số điện thoại:   {soDienThoai}");
            sb.AppendLine($"• Ngày sinh:       {ngaySinh}");
            sb.AppendLine($"• Khóa học:        {khoaHoc}");
            sb.AppendLine($"• Hình thức học:   {hinhThuc}");
            sb.AppendLine($"• Thời gian học:   {soThang} tháng");
            sb.AppendLine($"• TỔNG HỌC PHÍ:    {tongTien:N0} VNĐ");
            sb.AppendLine($"• Nhận email:      {nhanEmail}");
            sb.AppendLine("────────────────────────────────────");
            sb.AppendLine("Đăng ký thành công! Cảm ơn bạn đã lựa chọn khóa học.");

            MessageBox.Show(sb.ToString(), "Xác nhận đăng ký thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// 5.3 Xử lý nút LÀM MỚI (Reset Form về trạng thái ban đầu)
        /// </summary>
        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            // Xóa họ tên và số điện thoại
            txtHoTen.Clear();
            txtSoDienThoai.Clear();

            // Đưa ngày sinh về ngày hiện tại
            dtpNgaySinh.Value = DateTime.Now;

            // Bỏ chọn nhận email
            chkNhanEmail.Checked = false;

            // Chọn lại khóa học đầu tiên
            if (cboKhoaHoc.Items.Count > 0)
            {
                cboKhoaHoc.SelectedIndex = 0;
            }

            // Chọn lại hình thức Online
            radOnline.Checked = true;

            // Đưa số tháng về 1
            numSoThang.Value = 1;

            // Cập nhật lại tổng học phí ban đầu
            CapNhatTongTien();

            // Đưa con trỏ nhập liệu về ô Họ tên
            txtHoTen.Focus();
        }

        /// <summary>
        /// 5.4 Xử lý nút THOÁT (Hỏi xác nhận trước khi đóng)
        /// </summary>
        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có chắc chắn muốn thoát khỏi chương trình?",
                "Xác nhận thoát",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            // Để trống
        }
    }
}