﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace Lab03_QuanLySinhVienOOP
{
    internal class Program
    {
        // Khởi tạo đối tượng quản lý service
        private static QuanLySinhVien qlsv = new QuanLySinhVien();

        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;
            Console.Title = "COMP1019 - Lab 03: Quản lý sinh viên OOP | Trần Vũ Hạo Phát";

            int luaChon = -1;
            do
            {
                Console.Clear();
                HienThiBanner();
                HienThiMenu();

                luaChon = NhapSoNguyen(" » Chọn chức năng [0-8]: ");
                Console.WriteLine();

                switch (luaChon)
                {
                    case 1:
                        InTieuDe("1. THÊM SINH VIÊN MỚI");
                        ChucNangThemSinhVien();
                        break;

                    case 2:
                        InTieuDe("2. XUẤT DANH SÁCH TẤT CẢ SINH VIÊN");
                        InBangDanhSach(qlsv.LayDanhSach());
                        break;

                    case 3:
                        InTieuDe("3. TÌM KIẾM SINH VIÊN THEO MÃ");
                        ChucNangTimTheoMa();
                        break;

                    case 4:
                        InTieuDe("4. TÌM KIẾM SINH VIÊN THEO TÊN");
                        ChucNangTimTheoTen();
                        break;

                    case 5:
                        InTieuDe("5. CẬP NHẬT ĐIỂM TRUNG BÌNH");
                        ChucNangSuaDiem();
                        break;

                    case 6:
                        InTieuDe("6. XÓA SINH VIÊN KHỎI DANH SÁCH");
                        ChucNangXoaSinhVien();
                        break;

                    case 7:
                        InTieuDe("7. DANH SÁCH SẮP XẾP THEO ĐIỂM GIẢM DẦN");
                        InBangDanhSach(qlsv.SapXepTheoDiemGiamDan());
                        break;

                    case 8:
                        InTieuDe("8. DANH SÁCH SINH VIÊN ĐẠT (ĐIỂM TB >= 5.0)");
                        InBangDanhSach(qlsv.LocSinhVienDat());
                        break;

                    case 0:
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Console.WriteLine("╔════════════════════════════════════════════════════════════════════╗");
                        Console.WriteLine("║        ĐÃ THOÁT CHƯƠNG TRÌNH QUẢN LÝ SINH VIÊN. TẠM BIỆT!          ║");
                        Console.WriteLine("╚════════════════════════════════════════════════════════════════════╝");
                        Console.ResetColor();
                        break;

                    default:
                        InLoi("Lựa chọn không hợp lệ! Vui lòng chọn từ 0 đến 8.");
                        break;
                }

                if (luaChon != 0)
                {
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.Write("  [Nhấn phím bất kỳ để quay lại Menu...]");
                    Console.ResetColor();
                    Console.ReadKey();
                }

            } while (luaChon != 0);
        }

        // =========================================================================
        // CÁC HÀM XỬ LÝ CHỨC NĂNG NGHIỆP VỤ
        // =========================================================================

        static void ChucNangThemSinhVien()
        {
            string maSV = NhapChuoi(" » Nhập mã sinh viên: ");
            if (qlsv.TimTheoMa(maSV) != null)
            {
                InLoi($"Mã sinh viên '{maSV}' đã tồn tại trong hệ thống!");
                return;
            }

            string hoTen = NhapChuoi(" » Nhập họ và tên: ");
            DateTime ngaySinh = NhapNgayThang(" » Nhập ngày sinh (dd/MM/yyyy): ");
            string maLop = NhapChuoi(" » Nhập mã lớp: ");
            double diemTB = NhapDiem(" » Nhập điểm trung bình (0.0 - 10.0): ");

            SinhVien sv = new SinhVien(maSV, hoTen, ngaySinh, maLop, diemTB);
            if (qlsv.Them(sv))
            {
                InThanhCong($"Đã thêm sinh viên [{maSV} - {hoTen}] vào danh sách!");
            }
            else
            {
                InLoi("Thêm thất bại do trùng mã!");
            }
        }

        static void ChucNangTimTheoMa()
        {
            string maSV = NhapChuoi(" » Nhập mã sinh viên cần tìm: ");
            SinhVien sv = qlsv.TimTheoMa(maSV);
            if (sv != null)
            {
                InThanhCong("Đã tìm thấy sinh viên:");
                InBangDanhSach(new List<SinhVien> { sv });
            }
            else
            {
                InLoi($"Không tìm thấy sinh viên có mã '{maSV}'!");
            }
        }

        static void ChucNangTimTheoTen()
        {
            string tuKhoa = NhapChuoi(" » Nhập từ khóa tên cần tìm: ");
            var ketQua = qlsv.TimTheoTen(tuKhoa);
            if (ketQua.Count > 0)
            {
                InThanhCong($"Tìm thấy {ketQua.Count} sinh viên phù hợp với từ khóa '{tuKhoa}':");
                InBangDanhSach(ketQua);
            }
            else
            {
                InLoi($"Không tìm thấy sinh viên nào có tên chứa từ khóa '{tuKhoa}'!");
            }
        }

        static void ChucNangSuaDiem()
        {
            string maSV = NhapChuoi(" » Nhập mã sinh viên cần sửa điểm: ");
            SinhVien sv = qlsv.TimTheoMa(maSV);
            if (sv == null)
            {
                InLoi($"Không tìm thấy sinh viên có mã '{maSV}'!");
                return;
            }

            Console.WriteLine($"  ► Thông tin hiện tại: {sv.HoTen} | Lớp: {sv.MaLop} | Điểm cũ: {sv.DiemTrungBinh}");
            double diemMoi = NhapDiem(" » Nhập điểm trung bình mới (0.0 - 10.0): ");

            if (qlsv.SuaDiem(maSV, diemMoi))
            {
                InThanhCong($"Đã cập nhật điểm cho sinh viên {maSV} thành {diemMoi:0.0} (Xếp loại: {sv.XepLoai()})!");
            }
        }

        static void ChucNangXoaSinhVien()
        {
            string maSV = NhapChuoi(" » Nhập mã sinh viên muốn xóa: ");
            SinhVien sv = qlsv.TimTheoMa(maSV);
            if (sv == null)
            {
                InLoi($"Không tìm thấy sinh viên có mã '{maSV}' để xóa!");
                return;
            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write($"  ⚠ Bạn có chắc chắn muốn xóa sinh viên [{sv.MaSinhVien} - {sv.HoTen}]? (y/n): ");
            Console.ResetColor();
            string xacNhan = Console.ReadLine();
            if (xacNhan?.Trim().ToLower() == "y")
            {
                qlsv.Xoa(maSV);
                InThanhCong($"Đã xóa thành công sinh viên {maSV} khỏi danh sách!");
            }
            else
            {
                Console.WriteLine("  >> Đã hủy thao tác xóa.");
            }
        }

        // =========================================================================
        // CÁC HÀM NHẬP DỮ LIỆU CHỐNG CRASH (VALIDATION)
        // =========================================================================

        static string NhapChuoi(string message)
        {
            while (true)
            {
                Console.Write(message);
                string str = Console.ReadLine()?.Trim();
                if (!string.IsNullOrEmpty(str)) return str;
                InLoi("Dữ liệu không được để trống! Vui lòng nhập lại.");
            }
        }

        static int NhapSoNguyen(string message)
        {
            while (true)
            {
                Console.Write(message);
                if (int.TryParse(Console.ReadLine(), out int n)) return n;
                InLoi("Vui lòng nhập một số nguyên hợp lệ!");
            }
        }

        static double NhapDiem(string message)
        {
            while (true)
            {
                Console.Write(message);
                string input = Console.ReadLine();
                // Thay dấu phẩy bằng dấu chấm để nhận dạng số thực
                input = input?.Replace(',', '.');
                if (double.TryParse(input, NumberStyles.Any, CultureInfo.InvariantCulture, out double diem))
                {
                    if (diem >= 0.0 && diem <= 10.0) return diem;
                    InLoi("Điểm trung bình phải nằm trong khoảng từ 0.0 đến 10.0!");
                }
                else
                {
                    InLoi("Điểm phải là số thực hợp lệ (ví dụ: 8.5)!");
                }
            }
        }

        static DateTime NhapNgayThang(string message)
        {
            while (true)
            {
                Console.Write(message);
                string input = Console.ReadLine()?.Trim();
                if (DateTime.TryParseExact(input, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime dt))
                {
                    return dt;
                }
                InLoi("Định dạng ngày không hợp lệ! Vui lòng nhập theo mẫu dd/MM/yyyy (ví dụ: 15/08/2004).");
            }
        }

        // =========================================================================
        // GIAO DIỆN & BẢNG XUẤT THÔNG TIN
        // =========================================================================

        static void HienThiBanner()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("╔════════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║            HỌC PHẦN COMP1019 - LẬP TRÌNH TRÊN WINDOWS              ║");
            Console.WriteLine("║            LAB 03: HỆ THỐNG QUẢN LÝ SINH VIÊN (OOP - C#)           ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════════════════╝");
            Console.ResetColor();
        }

        static void HienThiMenu()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("┌───────────────────────────── MENU CHÍNH ───────────────────────────┐");
            Console.WriteLine("│  [1] Thêm sinh viên mới             [5] Sửa điểm trung bình        │");
            Console.WriteLine("│  [2] Xuất danh sách sinh viên       [6] Xóa sinh viên              │");
            Console.WriteLine("│  [3] Tìm kiếm theo mã               [7] Sắp xếp theo điểm giảm dần │");
            Console.WriteLine("│  [4] Tìm kiếm theo họ tên           [8] Lọc danh sách SV đạt (>=5) │");
            Console.WriteLine("│  ───────────────────────────────────────────────────────────────── │");
            Console.WriteLine("│  [0] Thoát chương trình                                            │");
            Console.WriteLine("└────────────────────────────────────────────────────────────────────┘");
            Console.ResetColor();
        }

        static void InBangDanhSach(List<SinhVien> list)
        {
            if (list == null || list.Count == 0)
            {
                InCanhBao("Danh sách hiện tại đang trống!");
                return;
            }

            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("┌──────────┬──────────────────────┬────────────┬──────────┬──────────┬────────────┐");
            Console.WriteLine("│ Mã SV    │ Họ và tên            │ Ngày sinh  │ Lớp      │ Điểm TB  │ Xếp loại   │");
            Console.WriteLine("├──────────┼──────────────────────┼────────────┼──────────┼──────────┼────────────┤");
            Console.ResetColor();

            foreach (var sv in list)
            {
                Console.WriteLine($"│ {sv.MaSinhVien,-8} │ {sv.HoTen,-20} │ {sv.NgaySinh:dd/MM/yyyy} │ {sv.MaLop,-8} │ {sv.DiemTrungBinh,8:0.0} │ {sv.XepLoai(),-10} │");
            }

            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("└──────────┴──────────────────────┴────────────┴──────────┴──────────┴────────────┘");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"  ► Tổng số sinh viên: {list.Count}");
            Console.ResetColor();
        }

        static void InTieuDe(string title)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"═══► {title}\n");
            Console.ResetColor();
        }

        static void InThanhCong(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"  ✔ [THÀNH CÔNG]: {msg}");
            Console.ResetColor();
        }

        static void InLoi(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"  ✖ [LỖI]: {msg}");
            Console.ResetColor();
        }

        static void InCanhBao(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"  ⚠ [CẢNH BÁO]: {msg}");
            Console.ResetColor();
        }
    }
}