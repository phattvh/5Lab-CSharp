﻿using System;

namespace Lab03_QuanLySinhVienOOP
{
    /// <summary>
    /// Class SinhVien kế thừa từ class Nguoi
    /// </summary>
    public class SinhVien : Nguoi
    {
        // Field lưu trữ điểm để kiểm tra ràng buộc 0 - 10
        private double _diemTrungBinh;

        // Properties riêng của SinhVien
        public string MaSinhVien { get; set; }
        public string MaLop { get; set; }

        /// <summary>
        /// Property có kiểm tra dữ liệu đầu vào: Điểm phải từ 0 đến 10
        /// </summary>
        public double DiemTrungBinh
        {
            get => _diemTrungBinh;
            set
            {
                if (value < 0 || value > 10)
                {
                    throw new ArgumentOutOfRangeException("Điểm trung bình phải nằm trong khoảng từ 0.0 đến 10.0!");
                }
                _diemTrungBinh = value;
            }
        }

        // Constructor mặc định
        public SinhVien() : base()
        {
            MaSinhVien = string.Empty;
            MaLop = string.Empty;
            _diemTrungBinh = 0;
        }

        // Constructor đầy đủ tham số (gọi lại constructor của class cha qua từ khóa base)
        public SinhVien(string maSV, string hoTen, DateTime ngaySinh, string maLop, double diemTB)
            : base(hoTen, ngaySinh)
        {
            MaSinhVien = maSV;
            MaLop = maLop;
            DiemTrungBinh = diemTB; // Gán qua Property để tự động kiểm tra khoảng [0 - 10]
        }

        /// <summary>
        /// Xếp loại học lực dựa trên Điểm trung bình
        /// </summary>
        public string XepLoai()
        {
            if (DiemTrungBinh >= 8.5) return "Xuất sắc";
            if (DiemTrungBinh >= 8.0) return "Giỏi";
            if (DiemTrungBinh >= 6.5) return "Khá";
            if (DiemTrungBinh >= 5.0) return "Trung bình";
            return "Yếu";
        }

        /// <summary>
        /// Ghi đè (override) phương thức của class cha để bổ sung thông tin sinh viên
        /// </summary>
        public override string LayThongTin()
        {
            return $"[Mã SV: {MaSinhVien,-8}] Họ tên: {HoTen,-20} | Lớp: {MaLop,-8} | Điểm TB: {DiemTrungBinh,4:0.0} | Xếp loại: {XepLoai()}";
        }
    }
}