﻿using System;

namespace Lab03_QuanLySinhVienOOP
{
    /// <summary>
    /// Class cha mô tả thông tin cơ bản của một con người
    /// </summary>
    public class Nguoi
    {
        // Properties
        public string HoTen { get; set; }
        public DateTime NgaySinh { get; set; }

        // Constructor không tham số
        public Nguoi()
        {
            HoTen = string.Empty;
            NgaySinh = DateTime.Now;
        }

        // Constructor có tham số
        public Nguoi(string hoTen, DateTime ngaySinh)
        {
            HoTen = hoTen;
            NgaySinh = ngaySinh;
        }

        /// <summary>
        /// Phương thức ảo (virtual) để class con có thể ghi đè (override)
        /// </summary>
        public virtual string LayThongTin()
        {
            return $"Họ tên: {HoTen} | Ngày sinh: {NgaySinh:dd/MM/yyyy}";
        }
    }
}