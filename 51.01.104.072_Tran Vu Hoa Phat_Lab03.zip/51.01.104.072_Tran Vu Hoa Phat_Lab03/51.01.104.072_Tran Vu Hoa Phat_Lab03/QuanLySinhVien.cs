﻿using System;
using System.Collections.Generic;
using System.Linq; // Sử dụng thư viện LINQ

namespace Lab03_QuanLySinhVienOOP
{
    public class QuanLySinhVien
    {
        // Danh sách sinh viên lưu trong bộ nhớ
        private List<SinhVien> _danhSach;

        public QuanLySinhVien()
        {
            _danhSach = new List<SinhVien>();
            KhoiTaoDuLieuMau(); // Nạp sẵn vài sinh viên để dễ kiểm thử
        }

        /// <summary>
        /// Dữ liệu mẫu ban đầu để giảng viên chấm nhanh mà không cần gõ từ đầu
        /// </summary>
        private void KhoiTaoDuLieuMau()
        {
            _danhSach.Add(new SinhVien("SV001", "Nguyễn Văn An", new DateTime(2004, 5, 12), "CNTT01", 8.6));
            _danhSach.Add(new SinhVien("SV002", "Trần Thị Bích", new DateTime(2004, 11, 20), "KTPM02", 7.2));
            _danhSach.Add(new SinhVien("SV003", "Lê Hoàng Cường", new DateTime(2003, 3, 15), "CNTT01", 4.5));
            _danhSach.Add(new SinhVien("SV004", "Phạm Quốc Dũng", new DateTime(2004, 8, 8), "HTTT01", 9.1));
            _danhSach.Add(new SinhVien("SV005", "Vũ Mai Phương", new DateTime(2004, 2, 28), "CNTT02", 5.8));
        }

        public List<SinhVien> LayDanhSach()
        {
            return _danhSach;
        }

        /// <summary>
        /// [Chức năng 1] Thêm sinh viên (Kiểm tra trùng mã)
        /// </summary>
        public bool Them(SinhVien sv)
        {
            // Dùng LINQ Any để kiểm tra mã sinh viên đã tồn tại chưa
            if (_danhSach.Any(s => s.MaSinhVien.Equals(sv.MaSinhVien, StringComparison.OrdinalIgnoreCase)))
            {
                return false; // Trùng mã
            }
            _danhSach.Add(sv);
            return true;
        }

        /// <summary>
        /// [Chức năng 3] Tìm sinh viên theo mã (Dùng LINQ FirstOrDefault)
        /// </summary>
        public SinhVien TimTheoMa(string maSV)
        {
            return _danhSach.FirstOrDefault(s => s.MaSinhVien.Equals(maSV, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// [Chức năng 4] Tìm sinh viên theo tên (Dùng LINQ Where + Contains)
        /// </summary>
        public List<SinhVien> TimTheoTen(string tuKhoa)
        {
            return _danhSach
                .Where(s => s.HoTen.IndexOf(tuKhoa, StringComparison.OrdinalIgnoreCase) >= 0)
                .ToList();
        }

        /// <summary>
        /// [Chức năng 5] Sửa điểm trung bình
        /// </summary>
        public bool SuaDiem(string maSV, double diemMoi)
        {
            SinhVien sv = TimTheoMa(maSV);
            if (sv == null) return false;

            sv.DiemTrungBinh = diemMoi;
            return true;
        }

        /// <summary>
        /// [Chức năng 6] Xóa sinh viên theo mã
        /// </summary>
        public bool Xoa(string maSV)
        {
            SinhVien sv = TimTheoMa(maSV);
            if (sv == null) return false;

            _danhSach.Remove(sv);
            return true;
        }

        /// <summary>
        /// [Chức năng 7] Sắp xếp theo điểm giảm dần (Dùng LINQ OrderByDescending)
        /// </summary>
        public List<SinhVien> SapXepTheoDiemGiamDan()
        {
            return _danhSach.OrderByDescending(s => s.DiemTrungBinh).ToList();
        }

        /// <summary>
        /// [Chức năng 8] Lọc sinh viên đạt (Điểm TB >= 5.0 - Dùng LINQ Where)
        /// </summary>
        public List<SinhVien> LocSinhVienDat()
        {
            return _danhSach.Where(s => s.DiemTrungBinh >= 5.0).ToList();
        }
    }
}