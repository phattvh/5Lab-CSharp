﻿using System;
using System.Text;

namespace MSSV_HoTen_Lab02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Thiết lập font chữ tiếng Việt có dấu cho cửa sổ Console
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;
            Console.Title = "COMP1019 - Lab 02: Quản lý mảng số nguyên | Trần Vũ Hạo Phát";

            int[] arr = null; // Khởi tạo mảng ban đầu
            int luaChon = -1;

            do
            {
                Console.Clear();
                // 1. Hiển thị Header & Menu
                HienThiBanner();
                HienThiTrangThaiMang(arr);
                HienThiMenu();

                // 2. Nhập lựa chọn
                luaChon = NhapSoNguyen(" » Chọn chức năng [0-7]: ");
                Console.WriteLine();

                // 3. Kiểm tra nếu chưa nhập mảng mà chọn chức năng xử lý
                if (luaChon >= 2 && luaChon <= 7 && (arr == null || arr.Length == 0))
                {
                    InCanhBao("Bạn chưa nhập dữ liệu mảng! Vui lòng chọn chức năng [1] trước.");
                }
                else
                {
                    switch (luaChon)
                    {
                        case 1:
                            InTieuDeChucNang("1. NHẬP DỮ LIỆU MẢNG SỐ NGUYÊN");
                            arr = NhapMang();
                            InThanhCong("Đã nhập dữ liệu mảng thành công!");
                            break;

                        case 2:
                            InTieuDeChucNang("2. XUẤT CÁC PHẦN TỬ TRONG MẢNG");
                            XuatMang(arr);
                            break;

                        case 3:
                            InTieuDeChucNang("3. TÍNH TỔNG CÁC PHẦN TỬ");
                            XuatMang(arr);
                            int tong = TinhTong(arr);
                            InHopKetQua($"Tổng giá trị tất cả phần tử trong mảng: {tong}");
                            break;

                        case 4:
                            InTieuDeChucNang("4. TÌM GIÁ TRỊ LỚN NHẤT & NHỎ NHẤT");
                            XuatMang(arr);
                            int max = TimMax(arr);
                            int min = TimMin(arr);
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine($"  ► Giá trị lớn nhất (Max) : {max}");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine($"  ► Giá trị nhỏ nhất (Min) : {min}");
                            Console.ResetColor();
                            break;

                        case 5:
                            InTieuDeChucNang("5. THỐNG KÊ SỐ LƯỢNG CHẴN / LẺ");
                            XuatMang(arr);
                            int chan = DemChan(arr);
                            int le = DemLe(arr);
                            Console.WriteLine($"  ► Số lượng số chẵn : {chan}");
                            Console.WriteLine($"  ► Số lượng số lẻ   : {le}");
                            break;

                        case 6:
                            InTieuDeChucNang("6. SẮP XẾP MẢNG TĂNG DẦN (INTERCHANGE SORT)");
                            Console.Write("  ► Mảng ban đầu:       ");
                            InMangNganGon(arr);

                            SapXepTangDan(arr);

                            Console.Write("  ► Mảng sau sắp xếp:   ");
                            InMangNganGon(arr);
                            InThanhCong("Đã sắp xếp mảng tăng dần thành công!");
                            break;

                        case 7:
                            InTieuDeChucNang("7. TÌM KIẾM PHẦN TỬ TRONG MẢNG");
                            XuatMang(arr);
                            int x = NhapSoNguyen("  » Nhập giá trị x cần tìm: ");
                            int viTri = TimKiem(arr, x);
                            if (viTri != -1)
                            {
                                InThanhCong($"Tìm thấy {x} tại vị trí index [{viTri}] (phần tử thứ {viTri + 1} trong mảng).");
                            }
                            else
                            {
                                InLoi($"Không tìm thấy giá trị {x} trong mảng!");
                            }
                            break;

                        case 0:
                            Console.ForegroundColor = ConsoleColor.Magenta;
                            Console.WriteLine("╔══════════════════════════════════════════════════════════════╗");
                            Console.WriteLine("║        CẢM ƠN BẠN ĐÃ SỬ DỤNG CHƯƠNG TRÌNH! TẠM BIỆT!        ║");
                            Console.WriteLine("╚══════════════════════════════════════════════════════════════╝");
                            Console.ResetColor();
                            break;

                        default:
                            InLoi("Lựa chọn không hợp lệ! Vui lòng chỉ chọn từ 0 đến 7.");
                            break;
                    }
                }

                // Dừng màn hình để người dùng xem kết quả
                if (luaChon != 0)
                {
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.Write("  [Nhấn phím bất kỳ để quay lại Menu...]");
                    Console.ResetColor();
                    Console.ReadKey();
                }

            } while (luaChon != 0);
        }

        // =========================================================================
        // CÁC HÀM VẼ GIAO DIỆN (UI DESIGN)
        // =========================================================================

        static void HienThiBanner()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("╔══════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║            HỌC PHẦN COMP1019 - LẬP TRÌNH TRÊN WINDOWS        ║");
            Console.WriteLine("║               LAB 02: QUẢN LÝ MẢNG SỐ NGUYÊN C#              ║");
            Console.WriteLine("╚══════════════════════════════════════════════════════════════╝");
            Console.ResetColor();
        }

        static void HienThiTrangThaiMang(int[] a)
        {
            Console.Write("  [Trạng thái mảng]: ");
            if (a == null || a.Length == 0)
            {
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("(Chưa có dữ liệu - Vui lòng chọn 1 để nhập)");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write($"[Đã có {a.Length} phần tử] => ");
                InMangNganGon(a);
            }
            Console.ResetColor();
            Console.WriteLine();
        }

        static void HienThiMenu()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("┌─────────────────────────── MENU ─────────────────────────────┐");
            Console.WriteLine("│  [1] Nhập mảng số nguyên          [5] Đếm số chẵn / lẻ       │");
            Console.WriteLine("│  [2] Xuất các phần tử mảng        [6] Sắp xếp tăng dần       │");
            Console.WriteLine("│  [3] Tính tổng các phần tử        [7] Tìm kiếm phần tử x     │");
            Console.WriteLine("│  [4] Tìm giá trị Max / Min        [0] Thoát chương trình     │");
            Console.WriteLine("└──────────────────────────────────────────────────────────────┘");
            Console.ResetColor();
        }

        static void InTieuDeChucNang(string title)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"═══► {title}");
            Console.ResetColor();
            Console.WriteLine();
        }

        static void InThanhCong(string message)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\n  ✔ [THÀNH CÔNG]: {message}");
            Console.ResetColor();
        }

        static void InLoi(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"  ✖ [LỖI]: {message}");
            Console.ResetColor();
        }

        static void InCanhBao(string message)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"  ⚠ [CẢNH BÁO]: {message}");
            Console.ResetColor();
        }

        static void InHopKetQua(string content)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"  ┌────────────────────────────────────────────────────────┐");
            Console.WriteLine($"  │  ► {content,-52}│");
            Console.WriteLine($"  └────────────────────────────────────────────────────────┘");
            Console.ResetColor();
        }

        static void InMangNganGon(int[] a)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("[ " + string.Join(", ", a) + " ]");
            Console.ResetColor();
        }

        // =========================================================================
        // KIỂM TRA DỮ LIỆU ĐẦU VÀO (VALIDATION)
        // =========================================================================

        static int NhapSoNguyen(string message)
        {
            int giaTri;
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write(message);
                Console.ResetColor();
                string input = Console.ReadLine();
                if (int.TryParse(input, out giaTri))
                {
                    return giaTri;
                }
                InLoi("Giá trị phải là số nguyên. Vui lòng nhập lại!");
            }
        }

        static int NhapSoNguyenDuong(string message)
        {
            int giaTri;
            while (true)
            {
                giaTri = NhapSoNguyen(message);
                if (giaTri > 0)
                {
                    return giaTri;
                }
                InLoi("Số lượng phần tử n phải là số nguyên dương (> 0). Nhập lại!");
            }
        }

        // =========================================================================
        // CÁC HÀM XỬ LÝ MẢNG THEO ĐÚNG YÊU CẦU ĐỀ BÀI
        // =========================================================================

        static int[] NhapMang()
        {
            int n = NhapSoNguyenDuong("  » Nhập số lượng phần tử n: ");
            int[] a = new int[n];
            Console.WriteLine();
            for (int i = 0; i < n; i++)
            {
                a[i] = NhapSoNguyen($"     + Nhập a[{i}]: ");
            }
            return a;
        }

        static void XuatMang(int[] a)
        {
            Console.WriteLine("  Danh sách các phần tử trong mảng:");
            Console.ForegroundColor = ConsoleColor.Cyan;

            // In đường viền trên
            Console.Write("  ┌");
            for (int i = 0; i < a.Length; i++)
            {
                Console.Write("───────" + (i == a.Length - 1 ? "┐" : "┬"));
            }
            Console.WriteLine();

            // In giá trị phần tử
            Console.Write("  │");
            for (int i = 0; i < a.Length; i++)
            {
                Console.Write($"{a[i],5}  │");
            }
            Console.WriteLine();

            // In đường viền dưới
            Console.Write("  └");
            for (int i = 0; i < a.Length; i++)
            {
                Console.Write("───────" + (i == a.Length - 1 ? "┘" : "┴"));
            }
            Console.WriteLine();

            // In chỉ số index [0], [1], ...
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.Write("   ");
            for (int i = 0; i < a.Length; i++)
            {
                Console.Write($"  [{i}]   ");
            }
            Console.WriteLine("\n");
            Console.ResetColor();
        }

        static int TinhTong(int[] a)
        {
            int tong = 0;
            for (int i = 0; i < a.Length; i++)
            {
                tong += a[i];
            }
            return tong;
        }

        static int TimMax(int[] a)
        {
            int max = a[0];
            for (int i = 1; i < a.Length; i++)
            {
                if (a[i] > max) max = a[i];
            }
            return max;
        }

        static int TimMin(int[] a)
        {
            int min = a[0];
            for (int i = 1; i < a.Length; i++)
            {
                if (a[i] < min) min = a[i];
            }
            return min;
        }

        static int DemChan(int[] a)
        {
            int dem = 0;
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] % 2 == 0) dem++;
            }
            return dem;
        }

        static int DemLe(int[] a)
        {
            int dem = 0;
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] % 2 != 0) dem++;
            }
            return dem;
        }

        static void SapXepTangDan(int[] a)
        {
            for (int i = 0; i < a.Length - 1; i++)
            {
                for (int j = i + 1; j < a.Length; j++)
                {
                    if (a[i] > a[j])
                    {
                        int temp = a[i];
                        a[i] = a[j];
                        a[j] = temp;
                    }
                }
            }
        }

        static int TimKiem(int[] a, int x)
        {
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] == x) return i;
            }
            return -1;
        }
    }
}